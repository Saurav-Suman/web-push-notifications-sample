/**
 * This module sends an http request to nodejs server which notifies the Firebase Cloud Messaging
 * API to dispatch notifications to all subscribers
 */
(function (root, factory){
    'use strict';

    if (typeof define === 'function' && define.amd){
        // AMD. Register as an anonymous module.
        define(['exports'], factory);

    } else if (typeof exports === 'object'){
        // CommonJS
        factory(exports);

    } else {
        // Browser globals
        factory((root.DesktopNotification = {}));

    }
}(( typeof window === 'object' && window ) || this, function (DesktopNotification) {

    'use strict';

    DesktopNotification.send = function(message, imageUrl, iconUrl){

        /* Send desktop notification to all subscribers of new klip being added */
        fetch("http://localhost:3000/notify", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify({
                "user_id": 1,
                "notification_message": message,
                "image": imageUrl,
                "icon": iconUrl
            })
        })
        .then(function (res) {
            if (res.ok) return res.json();

            console.error('Network response was not ok.')
        })
        .then(function (json) {
            console.log(json);
        });

    };
}));