//============================================================================================
// SETUP OUR SERVICE WORKER
//============================================================================================
/**
 * Checks for existence of service worker in the navigator object and performs setup for
 * web push notifications.
 */
if("serviceWorker" in navigator) {
    
    var userId = 1; // HARDCODE THIS VALUE FOR NOW (DEV ACCOUNT USER ID)

    /* Registration returns a service worker promise object */
    navigator.serviceWorker.register("../js/desktop.notifications/service-worker.js").then(function(registration) {

        // Add user_id to local storage
        persistData('key', userId);

        /* Get subscription */
        return registration.pushManager.getSubscription().then(function(subscription) {

            /* If a subscription was found, return it */
            if(subscription) {
                console.log('User already subscribed.');
                /* If user already subscribed on client side we must ensure the subscription is still in database */
                return saveSubscription(subscription, userId, registration);
            } else {
                /* Otherwise pass in argument required to subscribe and show visible notification to end user */
                return registration.pushManager.subscribe({userVisibleOnly: true}).then(function (subscription) {
                    console.log('Subscribing the user.');
                    /* Save subscription to db */
                    return saveSubscription(subscription, userId, registration);
                });
            }
        });
    })
    .catch(function(err) {
        console.error("There was a problem with the Service Worker: " + err);
    });

    /* This fires when the service worker controlling this page changes.
    ex: a new worker has skipped waiting and became the new active worker (don't need method?) */
    navigator.serviceWorker.addEventListener('controllerchange', () => {
        console.log('A new service worker has taken control and is active.')
    });
}

/**
 * Sends subscription data to server and if successful, sets the service worker to update periodically
 * @param subscription: a push subscription object (https://developer.mozilla.org/en-US/docs/Web/API/PushSubscription)
 * @param userId: id of the user
 * @param registration: a service worker registration object (https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration)
 * @returns promise object for fetch API
 */
function saveSubscription(subscription, userId, registration) {
    /* Send http request and save subscription to db */
    return sendSubscriptionInfo(subscription, userId)
        .then(function(res) {
            if(res.ok) {
                /* Update worker periodically */
                setUpdateInterval(registration);
                return res.json();
            } else {
                console.error('Network response was not ok.')
            }
        })
        .then(function(json) {
            console.log(json);
            return subscription;
        });
}

/**
 * Retrieve encryption data required for payload transfer on chrome (must be chrome v.50+)
 * @param subscription: a push subscription object (https://developer.mozilla.org/en-US/docs/Web/API/PushSubscription)
 * @param userId: id of the user
 * @returns fetch: promise object for fetch API
 */
function sendSubscriptionInfo(subscription, userId) {

    /* Format data (this only works for chrome v.50+) */
    var rawKey = subscription.getKey ? subscription.getKey('p256dh') : '';
    var key = rawKey ? btoa(String.fromCharCode.apply(null, new Uint8Array(rawKey))) : '';
    var rawAuthSecret = subscription.getKey ? subscription.getKey('auth') : '';
    var authSecret = rawAuthSecret ? btoa(String.fromCharCode.apply(null, new Uint8Array(rawAuthSecret))) : '';
    var endpoint = subscription.endpoint;

    /* Data to send to server */
    var subscriptionInfo = {
        endpoint: endpoint,
        key: key,
        authSecret: authSecret,
        user_id: userId
    };

    /* Sending the endpoint and keys to our server route which checks existence and saves it to database */
    return fetch("http://localhost:3000/subscription", {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(subscriptionInfo)
    });
}

/**
 * Browser checks for updates automatically after navigations and functional events but you can also
 * trigger them manually. If you expect the user to be using your site for a long time without reloading,
 * you may want to call registration.update() on an interval (setInterval)
 * @param registration: a service worker registration object (https://developer.mozilla.org/en-US/docs/Web/API/ServiceWorkerRegistration)
 */
function setUpdateInterval(registration) {
    setInterval(function(){ registration.update(); }, 3000);
}

/**
 * Persist data into local storage
 * @param stringKey: the key
 * @param value: the value to persist
 */
function persistData(stringKey, value) {
    localforage.setItem(stringKey, value).then(function () {
        return localforage.getItem(stringKey);
    })
    .then(function(value) {
        console.log('The following value is set to local storage: ', value);
    })
    .catch(function(err) {
        console.error('An error occurred persisting data to local storage: ' + err);
    });
}

/* Sends a message to the service worker (triggers their 'message' listener) */
function sendMessage(json) {
    registration.active.postMessage(JSON.stringify({user_id: userId}));
}