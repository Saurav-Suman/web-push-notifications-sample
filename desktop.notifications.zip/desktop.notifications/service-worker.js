//============================================================================================
// SERVICE WORKER
//============================================================================================
/* For local storage */
importScripts('localforage.js');

//*********************************************************
// First event by service worker 
//*********************************************************
self.addEventListener('install', function(event) {
    console.log('Installing new service worker...');
    /* This will kick out the current active worker and activate itself */
    //self.skipWaiting();
});

//*********************************************************
// Receive messages
//*********************************************************
self.addEventListener('message', function(event){
    /* Set the data sent to this service worker */
    var data = JSON.parse(event.data);
});

//*********************************************************
// Listen for push notification events
//*********************************************************
self.addEventListener("push", function(event){
    /* Retrieves the payload sent */
    var payload = event.data ? JSON.parse(event.data.text()) : 'no payload';
    var notificationMessage = payload.notification_message;
    var image = payload.image;
    var icon = payload.icon;

    console.log('Received push event with payload: ', payload);

    // Get user id set from local storage
    event.waitUntil(localforage.getItem('key')
        .then(function(value) {
            /* Only receive push notification for the selected user */
            if(payload.user_id == value) {
                /* Show a new message notification */
                self.registration.showNotification("Klipfolio", {
                    body: notificationMessage,
                    image: image,
                    icon: icon
                })
            }
        })
        .catch(function(err) {
            console.log(err);
        })
    );
});

//*********************************************************
// Fire when push notification is clicked
//*********************************************************
self.addEventListener("notificationclick", function(event){
    event.waitUntil(
        clients.openWindow("/")
    );
});